data class PostX(
    val author: String,
    val body: String,
    val title: String,
    val uid: String
)
