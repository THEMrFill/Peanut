data class News(
    val paging: Paging,
    val posts: List<Post>
)
