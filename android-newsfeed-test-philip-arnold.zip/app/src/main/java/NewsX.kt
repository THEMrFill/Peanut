data class NewsX(
    val paging: PagingX,
    val posts: List<PostX>
)
