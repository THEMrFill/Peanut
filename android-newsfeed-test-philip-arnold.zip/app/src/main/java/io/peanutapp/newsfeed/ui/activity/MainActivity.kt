package io.peanutapp.newsfeed.ui.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import io.peanutapp.newsfeed.R
import io.peanutapp.newsfeed.ui.main.MainFragment

class MainActivity : AppCompatActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)
    if (savedInstanceState == null) {
      supportFragmentManager.beginTransaction()
        .replace(R.id.container, MainFragment.newInstance())
        .commitNow()
    }
  }
}
