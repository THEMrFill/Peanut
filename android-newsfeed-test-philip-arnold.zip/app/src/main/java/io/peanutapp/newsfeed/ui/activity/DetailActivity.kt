package io.peanutapp.newsfeed.ui.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import io.peanutapp.newsfeed.R

class DetailActivity : AppCompatActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_detail)
  }
}
