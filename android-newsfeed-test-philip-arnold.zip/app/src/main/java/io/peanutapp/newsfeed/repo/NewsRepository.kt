package io.peanutapp.newsfeed.repo

import androidx.lifecycle.MutableLiveData
import io.peanutapp.newsfeed.api.UseCaseResult
import io.peanutapp.newsfeed.model.News

interface NewsRepository {
  suspend fun getNews(): UseCaseResult<News>
  suspend fun loadNews(liveData: MutableLiveData<News>)
}
