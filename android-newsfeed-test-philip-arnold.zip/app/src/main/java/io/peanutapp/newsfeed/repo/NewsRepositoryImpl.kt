package io.peanutapp.newsfeed.repo

import androidx.lifecycle.MutableLiveData
import io.peanutapp.newsfeed.api.ApiNetwork
import io.peanutapp.newsfeed.api.UseCaseResult
import io.peanutapp.newsfeed.model.News
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class NewsRepositoryImpl(private val api: ApiNetwork): NewsRepository {
  override suspend fun getNews(): UseCaseResult<News> {
    return try {
      val result = api.getProducts().await()
      UseCaseResult.Success(result)
    } catch (ex: Exception) {
      UseCaseResult.Error(ex)
    }
  }

  override suspend fun loadNews(liveData: MutableLiveData<News>) {
    when (val result = withContext(Dispatchers.IO) { getNews() }) {
      is UseCaseResult.Success -> {
        liveData.value = result.data
      }
      is UseCaseResult.Error -> {

      }
    }
  }
}
