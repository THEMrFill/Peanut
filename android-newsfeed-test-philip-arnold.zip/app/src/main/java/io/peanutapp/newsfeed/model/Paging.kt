package io.peanutapp.newsfeed.model

data class Paging(
    val next_cursor: String
)
