package io.peanutapp.newsfeed.model

data class News(
    val paging: Paging,
    val posts: List<Post>
)
