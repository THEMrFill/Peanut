# Peanut

Technical interview take-away exercise.

Please read the [specification for the exercise](https://docs.google.com/document/d/1lN_vND4L6ND4yicvZFa9uyzjC6Se8YGwzW5Srux7lc4/edit) on Google Docs.
